import { Component } from '@angular/core';
import{FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  n:string="name"
  e:string="emai"
  un:string="username"
  ps:string="password"

  regform=this.fb.group({
    name:'',
    email:'',
    uname:'',
    pswd:''
  })

  constructor(private fb:FormBuilder){}


  reg()
  {
    console.log(this.regform.value)
  }

}


