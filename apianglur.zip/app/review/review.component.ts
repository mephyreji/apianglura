import { Component } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../service/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent {
  id:any;
  reviewform=this.fb.group({
    review:['',[Validators.required]],
    rating:['',[Validators.required,Validators.pattern("[1-5]")]]
    
  })
  constructor(private fb:FormBuilder,private ar:ActivatedRoute,private ds:DataService,private r:Router){
    this.ar.params.subscribe(data=>this.id=data['id'])
    console.log(this.id)

  }


  submitReview(){
    console.log(this.reviewform.value)
    this.ds.addReview(this.id,this.reviewform.value).then(r=>r.json()).then(data=>{
      console.log(data)
      alert("review added")
      this.r.navigate(["dish",this.id])
    })

  }

}
