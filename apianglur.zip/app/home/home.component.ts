import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { DataService } from '../service/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  alldishes:any=[]
  constructor(private ds:DataService ,private r:Router){}
  ngOnInit(): void {
    this.ds.getDishes().then(r=>r.json()).then(data=>this.getdata(data))
  }
  getdata(d:any){
    this.alldishes=d
    console.log(this.alldishes)
  }
  renderDish(e:any){
    let id=e.target.id
    this.r.navigate(["dish",id])

  }
  addreview(e:any){
    let id=e.target.id 
    this.r.navigate(["rev",id])
  }

}
