import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { DishComponent } from './dish/dish.component';
import { ReviewComponent } from './review/review.component';
const routes: Routes = [
  {path:"reg",component:RegistrationComponent},
  {path:"home",component:HomeComponent},
  {path:"dish/:id",component:DishComponent},
  {path:"rev/:id",component:ReviewComponent},
  {path:"",component:LoginComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
