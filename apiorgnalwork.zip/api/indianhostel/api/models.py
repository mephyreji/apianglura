from django.db import models

# Create your models here.
# menu_items=[
#     {'id':1,'dish':"cb",'price':120,'rating':4.0,'category':"non veg"},
#     {'id':2,'dish':"curd rice",'price':120,'rating':3.0,'category':"veg"},
#     {'id':3,'dish':"fried chicken",'price':120,'rating':.0,'category':"non veg"},
#     {'id':4,'dish':"salad",'price':120,'rating':4.2,'category':"veg"},
#     {'id':5,'dish':"chopcy",'price':120,'rating':5.0,'category':"non veg"},
# ]

class Menu(models.Model):
    dish=models.CharField(max_length=100)
    price=models.IntegerField()
    rating=models.IntegerField()
    category=models.CharField(max_length=500)
    def __str__(self):
        return self.dish

