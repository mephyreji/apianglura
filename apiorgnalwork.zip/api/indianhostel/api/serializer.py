from rest_framework import serializers



class MenuSerializer(serializers.Serializer):
    dish=serializers.CharField()
    price=serializers.IntegerField()
    rating=serializers.IntegerField()
    category=serializers.CharField()